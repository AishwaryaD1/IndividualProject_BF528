# BF528-project-4-group-4

Names: Konrad Thorner, Aishwarya Deengar, Jia Liu, Morgan Rozman

Github: kthorner, AishwaryaD1, jialiu0103, morganroz

Email: kthorner@bu.edu, adeengar@bu.edu , jiliu@bu.edu, mrozman@bu.edu


scseq.R

Imports UMI matrix from alevin into Seurat. Performs filtering, clustering, and plotting.
